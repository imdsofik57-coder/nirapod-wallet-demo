# Nirapod Wallet Demo (Android)

This is a learning-only Android app project. It is not Nagad, is not affiliated with Nagad, and does not move real money.

## What it includes
- Bengali demo wallet home screen
- Fake demo balance
- Send Money / Cash Out / Recharge / Add Money / Transfer / Bill Pay / EMI / Merchant Pay buttons
- Each button only shows a demo toast; no network or payment functionality

## Build from an Android phone using GitHub Actions
1. Extract this ZIP.
2. Create/sign in to GitHub in your browser. If you are under 18, ask a parent/guardian to help with the account and any publishing steps.
3. Create a new repository, e.g. `nirapod-wallet-demo`.
4. Upload all files and folders from this project to the repository root (including `.github/workflows/build.yml`).
5. Open the repository's **Actions** tab. If prompted, enable workflows.
6. Choose **Build Android demo bundle** and tap **Run workflow**. Or wait for the first push build to finish.
7. Open the completed workflow run, scroll to **Artifacts**, and download `demo-debug-aab`.

## Important limitation
The generated `app-debug.aab` is for learning/testing only and is signed with the Android debug key. It is NOT a production-ready Play Store upload. To publish, the app needs a distinct brand/name, a privacy policy and store listing, policy review, and a properly secured upload key/release signing setup. Google Play Console account creation and publishing may require an adult account; do not share passwords or signing keys.

## Build an APK instead
In the workflow, change `gradle :app:bundleDebug` to `gradle :app:assembleDebug`, and change the artifact path to `app/build/outputs/apk/debug/app-debug.apk`. This APK can be downloaded and installed for testing, after allowing installation from that source.

## Technical
- Java Android app
- Android Gradle Plugin 8.7.3
- Compile SDK 35
- No external dependencies

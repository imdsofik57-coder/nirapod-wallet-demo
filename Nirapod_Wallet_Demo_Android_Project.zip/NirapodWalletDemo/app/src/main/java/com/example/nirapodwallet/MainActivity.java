package com.example.nirapodwallet;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int red = Color.rgb(198, 25, 44);
    private final int orange = Color.rgb(244, 112, 48);

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(red);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(248, 248, 248));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(24, 26, 24, 24);
        header.setBackgroundColor(red);

        TextView brand = new TextView(this);
        brand.setText("নিরাপদ ওয়ালেট");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(24);
        brand.setTypeface(null, Typeface.BOLD);
        header.addView(brand);

        TextView note = new TextView(this);
        note.setText("শুধু শেখার ডেমো • আসল টাকা লেনদেন হয় না");
        note.setTextColor(Color.WHITE);
        note.setTextSize(13);
        note.setPadding(0, 8, 0, 16);
        header.addView(note);

        TextView balanceLabel = new TextView(this);
        balanceLabel.setText("ডেমো ব্যালেন্স");
        balanceLabel.setTextColor(Color.WHITE);
        balanceLabel.setTextSize(15);
        header.addView(balanceLabel);

        TextView balance = new TextView(this);
        balance.setText("৳ ৫,০০০.০০");
        balance.setTextColor(Color.WHITE);
        balance.setTextSize(30);
        balance.setTypeface(null, Typeface.BOLD);
        header.addView(balance);
        root.addView(header);

        TextView title = new TextView(this);
        title.setText("সেবাসমূহ");
        title.setTextColor(Color.DKGRAY);
        title.setTextSize(19);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(20, 20, 20, 10);
        root.addView(title);

        String[][] actions = {
            {"টাকা পাঠান", "ক্যাশ আউট", "মোবাইল রিচার্জ"},
            {"অ্যাড মানি", "ট্রান্সফার", "বিল পে"},
            {"ইএমআই পেমেন্ট", "মার্চেন্ট পে", "লেনদেনের ইতিহাস"}
        };

        for (String[] rowItems : actions) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(12, 4, 12, 4);
            for (String label : rowItems) {
                Button b = new Button(this);
                b.setText(label);
                b.setTextSize(12);
                b.setAllCaps(false);
                b.setTextColor(red);
                b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 90, 1);
                p.setMargins(4, 4, 4, 4);
                row.addView(b, p);
                b.setOnClickListener(v -> Toast.makeText(
                    this, label + ": এটি শুধু ডেমো; কোনো টাকা লেনদেন হয় না।", Toast.LENGTH_LONG
                ).show());
            }
            root.addView(row);
        }

        TextView footer = new TextView(this);
        footer.setText("ডেমো অ্যাপ — কোনো ব্যাংক বা মোবাইল ফাইন্যান্স সেবার সঙ্গে যুক্ত নয়।");
        footer.setTextColor(Color.GRAY);
        footer.setTextSize(12);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(18, 24, 18, 20);
        root.addView(footer);

        setContentView(root);
    }
}
